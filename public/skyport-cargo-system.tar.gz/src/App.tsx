import React, { useState, useMemo } from 'react';
import {
  Sidebar,
  NavTab,
} from './components/Sidebar';
import { Header } from './components/Header';
import { MetricCards } from './components/MetricCards';
import { BentoGrid } from './components/BentoGrid';
import { KanbanBoard } from './components/KanbanBoard';
import { ScannerModal } from './components/ScannerModal';
import { PieceModal } from './components/PieceModal';
import { XRayModal } from './components/XRayModal';
import { DOModal } from './components/DOModal';
import { ExceptionModal } from './components/ExceptionModal';
import { ShiftModal } from './components/ShiftModal';
import { AuditModal } from './components/AuditModal';
import {
  INITIAL_CONSIGNMENTS,
  INITIAL_USERS,
  INITIAL_EXCEPTIONS,
  INITIAL_SHIFT_HANDOVER,
  INITIAL_AUDIT_LOGS,
} from './data/mockCargoData';
import {
  Consignment,
  UserProfile,
  ExceptionCase,
  ShiftHandover,
  AuditEvent,
  XRayResult,
} from './types/cargo';
import {
  ShieldAlert,
  CheckCircle2,
  AlertCircle,
  FileText,
  Calendar,
  Check,
} from 'lucide-react';
import { Language, translations } from './i18n/translations';

export default function App() {
  // Language State - Default to Indonesian as requested!
  const [lang, setLang] = useState<Language>('id');
  const t = translations[lang];

  // Core State
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [consignments, setConsignments] = useState<Consignment[]>(INITIAL_CONSIGNMENTS);
  const [allUsers, setAllUsers] = useState<UserProfile[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<UserProfile>(INITIAL_USERS[0]); // Sarah Miller (AVSEC)
  const [exceptions, setExceptions] = useState<ExceptionCase[]>(INITIAL_EXCEPTIONS);
  const [shiftData, setShiftData] = useState<ShiftHandover>(INITIAL_SHIFT_HANDOVER);
  const [auditLogs, setAuditLogs] = useState<AuditEvent[]>(INITIAL_AUDIT_LOGS);
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isPieceModalOpen, setIsPieceModalOpen] = useState(false);
  const [isXRayModalOpen, setIsXRayModalOpen] = useState(false);
  const [isDOModalOpen, setIsDOModalOpen] = useState(false);
  const [isExceptionModalOpen, setIsExceptionModalOpen] = useState(false);
  const [isShiftModalOpen, setIsShiftModalOpen] = useState(false);
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [selectedConsignment, setSelectedConsignment] = useState<Consignment | null>(null);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'warning' | 'error' | 'info'; text: string } | null>(null);

  const showToast = (text: string, type: 'success' | 'warning' | 'error' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4500);
  };

  // Filtered consignments based on search query
  const filteredConsignments = useMemo(() => {
    if (!searchQuery.trim()) return consignments;
    const q = searchQuery.toLowerCase();
    return consignments.filter(
      (c) =>
        c.awbNumber.toLowerCase().includes(q) ||
        c.flightNo.toLowerCase().includes(q) ||
        c.airline.toLowerCase().includes(q) ||
        c.shipper.toLowerCase().includes(q) ||
        c.consignee.toLowerCase().includes(q) ||
        c.destination.toLowerCase().includes(q) ||
        c.natureOfGoods.toLowerCase().includes(q) ||
        (c.deliveryOrder && c.deliveryOrder.doNumber.toLowerCase().includes(q)) ||
        c.pieces.some((p) => p.barcode.toLowerCase().includes(q))
    );
  }, [consignments, searchQuery]);

  // Aggregate metrics
  const totalPieces = consignments.reduce((acc, c) => acc + c.totalDeclaredPieces, 0);
  const xrayedPieces = consignments.reduce(
    (acc, c) => acc + c.pieces.filter((p) => p.xrayResult !== undefined).length,
    0
  );
  const pendingAvsecPieces = consignments
    .filter((c) => c.status === 'AWAITING_AVSEC' || c.status === 'XRAY_HOLD' || c.status === 'XRAY_REVIEW_REQUIRED')
    .reduce((acc, c) => acc + c.totalReceivedPieces, 0);
  const doIssuedCount = consignments.filter((c) => c.deliveryOrder?.status === 'ISSUED').length;
  const deliveredCount = consignments.filter((c) => c.status === 'DELIVERED').length;
  const openExceptionsCount = exceptions.filter((e) => e.status !== 'CLOSED' && e.status !== 'RESOLVED').length;

  // Handlers for operational state changes
  const handleRecordXRayResult = (
    consignmentId: string,
    result: XRayResult,
    notes: string,
    threatClass?: string
  ) => {
    setConsignments((prev) =>
      prev.map((c) => {
        if (c.id !== consignmentId) return c;

        const newInspection = {
          id: `XR-${Date.now().toString().slice(-4)}`,
          inspectedAt: new Date().toLocaleTimeString(),
          operatorId: currentUser.id,
          operatorName: currentUser.name,
          stationId: currentUser.station,
          scannerModel: 'Smiths Detection HI-SCAN 100100V-2is',
          result,
          notes,
          dataVersion: c.dataVersion,
          densityLevel: result === 'PASS' ? ('Low' as const) : ('Suspicious' as const),
          threatClass: (threatClass as any) || 'None',
        };

        const updatedPieces = c.pieces.map((p) => ({
          ...p,
          xrayResult: result,
          status: result === 'PASS' ? ('XRAY_PASS' as const) : ('XRAY_HOLD' as const),
          xrayTimestamp: new Date().toLocaleTimeString(),
          xrayOperator: currentUser.name,
        }));

        let newStatus = c.status;
        if (result === 'PASS') {
          newStatus = 'AWAITING_AVSEC';
        } else if (result === 'HOLD') {
          newStatus = 'XRAY_HOLD';
        } else if (result === 'REVIEW_REQUIRED') {
          newStatus = 'XRAY_REVIEW_REQUIRED';
        } else if (result === 'REJECT') {
          newStatus = 'XRAY_REJECTED';
        }

        return {
          ...c,
          status: newStatus,
          pieces: updatedPieces,
          xrayInspections: [newInspection, ...c.xrayInspections],
          lastUpdatedAt: new Date().toLocaleTimeString(),
        };
      })
    );

    if (result === 'HOLD' || result === 'REJECT') {
      const newExc: ExceptionCase = {
        id: `EXC-2026-${Date.now().toString().slice(-3)}`,
        caseNo: `EXC-2026-${Date.now().toString().slice(-3)}`,
        category: 'XRAY_THREAT_HOLD',
        title: lang === 'id' ? `Penahanan X-Ray: ${threatClass || 'Objek Mencurigakan'}` : `X-Ray Threat Hold: ${threatClass || 'Suspicious Object'}`,
        priority: 'CRITICAL',
        status: 'ASSIGNED',
        consignmentId,
        awbNumber: consignments.find((c) => c.id === consignmentId)?.awbNumber || '',
        assignedTo: 'Sarah Miller (AVSEC Officer)',
        createdAt: new Date().toLocaleTimeString(),
        dueAt: 'Within 30 mins',
        chronology: [
          {
            timestamp: new Date().toLocaleTimeString(),
            actor: currentUser.name,
            action: lang === 'id' ? 'Ancaman Terdeteksi pada X-Ray Dual-View' : 'Threat Flagged during Dual-View X-Ray Screening',
            note: notes,
          },
        ],
      };
      setExceptions((prev) => [newExc, ...prev]);
    }

    const newAudit: AuditEvent = {
      id: `AUD-${Date.now().toString().slice(-5)}`,
      occurredAt: new Date().toLocaleTimeString(),
      actor: currentUser.name,
      role: currentUser.role,
      action: 'RECORD_XRAY_RESULT',
      entityType: 'XRAY',
      entityId: consignmentId,
      description: `Recorded result ${result} on consignment ${consignmentId}. ThreatClass: ${threatClass || 'None'}.`,
      criticalControlMet: true,
      correlationId: `TX-${Date.now().toString().slice(-4)}`,
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    setIsXRayModalOpen(false);
    showToast(
      lang === 'id' ? `Hasil X-Ray ${result} dicatat. Status diperbarui sesuai SOP.` : `X-Ray inspection recorded: ${result}. State updated per SOP.`,
      result === 'PASS' ? 'success' : 'warning'
    );
  };

  const handleRecordAVSECDecision = (
    consignmentId: string,
    decision: 'APPROVED' | 'REJECTED' | 'HELD_FOR_SECONDARY',
    reason: string
  ) => {
    setConsignments((prev) =>
      prev.map((c) => {
        if (c.id !== consignmentId) return c;

        const newReview = {
          id: `AVS-${Date.now().toString().slice(-4)}`,
          decidedAt: new Date().toLocaleTimeString(),
          officerId: currentUser.id,
          officerName: currentUser.name,
          decision,
          reason,
          reviewedDataVersion: c.dataVersion,
          securityStampNo: `AVSEC-CGK-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        };

        let newStatus = c.status;
        let newDO = c.deliveryOrder;

        if (decision === 'APPROVED') {
          newStatus = 'AVSEC_APPROVED';
          if (!newDO) {
            newDO = {
              id: `DO-${Date.now().toString().slice(-4)}`,
              doNumber: `DO-2026-${c.airline.slice(0, 2).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`,
              version: 1,
              status: 'DRAFT',
              carrier: c.airline,
              flightNo: c.flightNo,
              destination: c.destination,
              customsSealNo: `BC-SEAL-${Math.floor(10000 + Math.random() * 90000)}`,
              totalPieces: c.totalReceivedPieces,
              totalGrossWeightKg: c.totalWeightKg,
            };
          }
        } else if (decision === 'REJECTED') {
          newStatus = 'AVSEC_REJECTED_OR_HELD';
        } else {
          newStatus = 'XRAY_HOLD';
        }

        return {
          ...c,
          status: newStatus,
          avsecReview: newReview,
          deliveryOrder: newDO,
          lastUpdatedAt: new Date().toLocaleTimeString(),
        };
      })
    );

    const newAudit: AuditEvent = {
      id: `AUD-${Date.now().toString().slice(-5)}`,
      occurredAt: new Date().toLocaleTimeString(),
      actor: currentUser.name,
      role: currentUser.role,
      action: 'AVSEC_DECISION',
      entityType: 'AVSEC',
      entityId: consignmentId,
      description: `AVSEC ${decision} granted by ${currentUser.name}. Reason: ${reason}`,
      criticalControlMet: true,
      correlationId: `TX-${Date.now().toString().slice(-4)}`,
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    setIsXRayModalOpen(false);
    showToast(
      lang === 'id' ? `Keputusan AVSEC [${decision}] dicatat pada versi snapshot.` : `AVSEC Decision [${decision}] recorded to snapshot version.`,
      decision === 'APPROVED' ? 'success' : 'error'
    );
  };

  const handleIssueDO = (consignmentId: string, customSealNo: string) => {
    setConsignments((prev) =>
      prev.map((c) => {
        if (c.id !== consignmentId) return c;
        if (!c.deliveryOrder) return c;

        const updatedDO = {
          ...c.deliveryOrder,
          status: 'ISSUED' as const,
          issuedAt: new Date().toLocaleTimeString(),
          issuedBy: currentUser.id,
          dispatcherName: currentUser.name,
          customsSealNo: customSealNo,
        };

        return {
          ...c,
          status: 'DO_ISSUED',
          deliveryOrder: updatedDO,
          lastUpdatedAt: new Date().toLocaleTimeString(),
        };
      })
    );

    const newAudit: AuditEvent = {
      id: `AUD-${Date.now().toString().slice(-5)}`,
      occurredAt: new Date().toLocaleTimeString(),
      actor: currentUser.name,
      role: currentUser.role,
      action: 'ISSUE_DELIVERY_ORDER',
      entityType: 'DO',
      entityId: consignmentId,
      description: `Delivery Order issued by Dispatch Officer ${currentUser.name}. Customs Seal: ${customSealNo}`,
      criticalControlMet: true,
      correlationId: `TX-${Date.now().toString().slice(-4)}`,
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    setIsDOModalOpen(false);
    showToast(
      lang === 'id' ? `Delivery Order (DO) berhasil diterbitkan dengan segel ${customSealNo}.` : `Delivery Order issued with seal ${customSealNo}. Ready for airline handover!`,
      'success'
    );
  };

  const handleConfirmHandover = (
    consignmentId: string,
    receiverName: string,
    airlineWarehouse: string,
    condition: 'INTACT_SEAL' | 'MINOR_TEAR' | 'DAMAGED_CRUSHED',
    signatureText: string
  ) => {
    setConsignments((prev) =>
      prev.map((c) => {
        if (c.id !== consignmentId) return c;

        const newPoH = {
          id: `POH-2026-${Date.now().toString().slice(-4)}`,
          proofNo: `POH-2026-${Date.now().toString().slice(-4)}-V1`,
          handoverTime: new Date().toLocaleTimeString(),
          doNumber: c.deliveryOrder?.doNumber || 'N/A',
          handedOverBy: `${currentUser.name} (${currentUser.roleLabel})`,
          receivedBy: receiverName,
          airlineWarehouse,
          plannedPieces: c.totalDeclaredPieces,
          actualPieces: c.totalReceivedPieces,
          conditionStatus: condition,
          digitalSignature: signatureText,
          notes: `Handover verified with intact seals. Signed digitally by ${receiverName}.`,
          verifiedPieceIds: c.pieces.map((p) => p.id),
        };

        const updatedPieces = c.pieces.map((p) => ({
          ...p,
          status: 'HANDED_OVER' as const,
          scannedAtHandover: true,
        }));

        return {
          ...c,
          status: 'DELIVERED',
          proofOfHandover: newPoH,
          pieces: updatedPieces,
          lastUpdatedAt: new Date().toLocaleTimeString(),
        };
      })
    );

    const newAudit: AuditEvent = {
      id: `AUD-${Date.now().toString().slice(-5)}`,
      occurredAt: new Date().toLocaleTimeString(),
      actor: currentUser.name,
      role: currentUser.role,
      action: 'CONFIRM_HANDOVER_POH',
      entityType: 'HANDOVER',
      entityId: consignmentId,
      description: `Digital Proof of Handover signed off by ${receiverName}. Status moved to DELIVERED.`,
      criticalControlMet: true,
      correlationId: `TX-${Date.now().toString().slice(-4)}`,
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    setIsDOModalOpen(false);
    showToast(
      lang === 'id' ? 'Serah terima terkonfirmasi! Bukti PoH digital telah dibuat. Kargo berstatus DELIVERED.' : 'Handover confirmed! Digital Proof of Handover (PoH) generated. Consignment marked DELIVERED.',
      'success'
    );
  };

  const handleUpdatePieceHandover = (consignmentId: string, pieceId: string, verified: boolean) => {
    setConsignments((prev) =>
      prev.map((c) => {
        if (c.id !== consignmentId) return c;
        const updatedPieces = c.pieces.map((p) => (p.id === pieceId ? { ...p, scannedAtHandover: verified } : p));
        return {
          ...c,
          pieces: updatedPieces,
        };
      })
    );
  };

  const handleAddNewConsignment = (newConsignment: Consignment) => {
    setConsignments((prev) => [newConsignment, ...prev]);
    showToast(
      lang === 'id' ? `AWB masuk ${newConsignment.awbNumber} berhasil diterima dan masuk antrean screening.` : `Inbound AWB ${newConsignment.awbNumber} accepted and queued for screening.`,
      'success'
    );
  };

  const handleResolveException = (exceptionId: string, resolutionNotes: string) => {
    setExceptions((prev) =>
      prev.map((e) => {
        if (e.id !== exceptionId) return e;
        return {
          ...e,
          status: 'RESOLVED',
          resolvedAt: new Date().toLocaleTimeString(),
          resolutionNotes,
          chronology: [
            ...e.chronology,
            {
              timestamp: new Date().toLocaleTimeString(),
              actor: currentUser.name,
              action: lang === 'id' ? 'Eksepsi Diselesaikan' : 'Exception Resolved',
              note: resolutionNotes,
            },
          ],
        };
      })
    );
    showToast(
      lang === 'id' ? `Kasus eksepsi ${exceptionId} berhasil diselesaikan.` : `Exception ${exceptionId} resolved per SOP.`,
      'success'
    );
  };

  const handleCreateException = (newCase: Partial<ExceptionCase>) => {
    const fullCase: ExceptionCase = {
      id: `EXC-2026-${Date.now().toString().slice(-3)}`,
      caseNo: `EXC-2026-${Date.now().toString().slice(-3)}`,
      category: newCase.category || 'XRAY_THREAT_HOLD',
      title: newCase.title || 'Operational Incident',
      priority: newCase.priority || 'HIGH',
      status: 'OPEN',
      consignmentId: newCase.consignmentId || 'CNS-MANUAL',
      awbNumber: newCase.awbNumber || 'UNKNOWN',
      assignedTo: newCase.assignedTo || currentUser.name,
      createdAt: new Date().toLocaleTimeString(),
      dueAt: 'Within 60 mins',
      chronology: newCase.chronology || [],
    };
    setExceptions((prev) => [fullCase, ...prev]);
    showToast(
      lang === 'id' ? `Tiket insiden ${fullCase.caseNo} telah dicatat dalam buku eksepsi.` : `Incident Case ${fullCase.caseNo} logged in exception ledger.`,
      'warning'
    );
  };

  const handleAcknowledgeShift = (supervisorName: string) => {
    setShiftData((prev) => ({
      ...prev,
      status: 'ACKNOWLEDGED',
      acknowledgedAt: new Date().toLocaleTimeString(),
      incomingSupervisor: supervisorName,
    }));
    showToast(
      lang === 'id' ? `Serah terima shift telah ditandatangani oleh ${supervisorName}.` : `Shift Handover acknowledged by ${supervisorName}.`,
      'success'
    );
  };

  return (
    <div className="flex h-screen bg-[#F8FAFC] text-slate-800 font-sans antialiased overflow-hidden">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2.5 px-4 py-3 rounded-2xl shadow-xl text-xs font-semibold animate-in slide-in-from-top-3 duration-200 border bg-white border-slate-200">
          {toastMessage.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />}
          {toastMessage.type === 'warning' && <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />}
          {toastMessage.type === 'error' && <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />}
          {toastMessage.type === 'info' && <Check className="w-4 h-4 text-blue-600 shrink-0" />}
          <span className="text-slate-900">{toastMessage.text}</span>
        </div>
      )}

      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          if (tab === 'shift') setIsShiftModalOpen(true);
          if (tab === 'audit') setIsAuditModalOpen(true);
          if (tab === 'exceptions') setIsExceptionModalOpen(true);
        }}
        openExceptionsCount={openExceptionsCount}
        pendingXrayCount={consignments.filter((c) => c.status === 'AWAITING_XRAY').length}
        pendingAvsecCount={consignments.filter((c) => c.status === 'AWAITING_AVSEC' || c.status === 'XRAY_HOLD').length}
        onOpenShiftModal={() => setIsShiftModalOpen(true)}
        currentLang={lang}
      />

      {/* Main Layout Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <Header
          currentUser={currentUser}
          allUsers={allUsers}
          onSwitchUser={(user) => {
            setCurrentUser(user);
            showToast(
              lang === 'id' ? `Petugas aktif diganti: ${user.name} (${user.roleLabel})` : `Active User switched to ${user.name} (${user.roleLabel})`,
              'info'
            );
          }}
          onOpenScanner={() => setIsScannerOpen(true)}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          unreadAlertsCount={openExceptionsCount + (consignments.filter((c) => c.slaStatus === 'WARNING').length)}
          currentLang={lang}
          onToggleLang={(newLang) => {
            setLang(newLang);
            showToast(
              newLang === 'id' ? 'Bahasa antarmuka diubah ke Bahasa Indonesia.' : 'Interface language switched to English.',
              'info'
            );
          }}
        />

        {/* Scrollable Workspace */}
        <main className="flex-1 overflow-y-auto p-8 space-y-7">
          {/* Welcome Banner Row (Matching reference image) */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold tracking-tight text-slate-900">
                  {t.greetingMorning}, {currentUser.name.split(' ')[0]}! 👋
                </h1>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {t.greetingSubtitle}
              </p>
            </div>

            {/* Date range picker pill from reference image */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 px-3.5 py-2 bg-white rounded-xl border border-slate-200/80 shadow-2xs text-xs font-semibold text-slate-700">
                <Calendar className="w-4 h-4 text-slate-400" />
                <span>{t.todayFilter}</span>
              </div>
            </div>
          </div>

          {/* 4 Metric Cards */}
          <MetricCards
            totalConsignments={filteredConsignments.length}
            totalPieces={totalPieces}
            xrayedPieces={xrayedPieces}
            pendingAvsecPieces={pendingAvsecPieces}
            doIssuedCount={doIssuedCount}
            deliveredCount={deliveredCount}
            currentLang={lang}
          />

          {/* Bento Grid (Stage progress, Donut, Flights, Duty Personnel, Stacked Bar Chart) */}
          <BentoGrid
            consignments={filteredConsignments}
            teamMembers={allUsers}
            onSelectConsignment={(c) => {
              setSelectedConsignment(c);
              setIsPieceModalOpen(true);
            }}
            onFilterByStatus={() => setActiveTab('kanban')}
            onOpenXRayModal={(c) => {
              setSelectedConsignment(c);
              setIsXRayModalOpen(true);
            }}
            currentLang={lang}
          />

          {/* Bottom Kanban Board (Matching reference image) */}
          <KanbanBoard
            consignments={filteredConsignments}
            currentUser={currentUser}
            onSelectConsignment={(c) => {
              setSelectedConsignment(c);
              setIsPieceModalOpen(true);
            }}
            onOpenXRayModal={(c) => {
              setSelectedConsignment(c);
              setIsXRayModalOpen(true);
            }}
            onOpenPieceModal={(c) => {
              setSelectedConsignment(c);
              setIsPieceModalOpen(true);
            }}
            onOpenDOModal={(c) => {
              setSelectedConsignment(c);
              setIsDOModalOpen(true);
            }}
            onOpenExceptionModal={(c) => {
              setSelectedConsignment(c);
              setIsExceptionModalOpen(true);
            }}
            onOpenScanner={() => setIsScannerOpen(true)}
            currentLang={lang}
          />

          {/* PRD Reference & System Architecture Footer Note */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200/80 text-xs text-slate-500 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="font-semibold text-slate-700">{t.systemFooter}</span>
              <span>· {t.baselineUAT}</span>
            </div>
            <div className="flex items-center gap-4 text-[11px] font-mono text-slate-400">
              <span>CR-01: AVSEC Lock Active</span>
              <span>CR-04: Piece Reconciliation</span>
              <span>CR-07: Proof of Handover</span>
              <span>CR-09: Immutable Audit</span>
            </div>
          </div>
        </main>
      </div>

      {/* Modals */}
      <ScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        consignments={consignments}
        onAddNewConsignment={handleAddNewConsignment}
        onLogScanEvent={(barcode, res) => {
          const audit: AuditEvent = {
            id: `AUD-${Date.now().toString().slice(-5)}`,
            occurredAt: new Date().toLocaleTimeString(),
            actor: currentUser.name,
            role: currentUser.role,
            action: 'BARCODE_SCAN_EVENT',
            entityType: 'CONSIGNMENT',
            entityId: barcode,
            description: `Physical scanner input registered for [${barcode}]. Idempotent check passed.`,
            criticalControlMet: true,
            correlationId: `TX-SCAN-${Date.now().toString().slice(-4)}`,
          };
          setAuditLogs((prev) => [audit, ...prev]);
        }}
      />

      <PieceModal
        isOpen={isPieceModalOpen}
        onClose={() => setIsPieceModalOpen(false)}
        consignment={selectedConsignment}
        onUpdatePieceHandover={handleUpdatePieceHandover}
      />

      <XRayModal
        isOpen={isXRayModalOpen}
        onClose={() => setIsXRayModalOpen(false)}
        consignment={selectedConsignment}
        currentUser={currentUser}
        onRecordXRayResult={handleRecordXRayResult}
        onRecordAVSECDecision={handleRecordAVSECDecision}
      />

      <DOModal
        isOpen={isDOModalOpen}
        onClose={() => setIsDOModalOpen(false)}
        consignment={selectedConsignment}
        currentUser={currentUser}
        onIssueDO={handleIssueDO}
        onConfirmHandover={handleConfirmHandover}
      />

      <ExceptionModal
        isOpen={isExceptionModalOpen}
        onClose={() => setIsExceptionModalOpen(false)}
        exceptions={exceptions}
        selectedConsignment={selectedConsignment}
        onResolveException={handleResolveException}
        onCreateException={handleCreateException}
      />

      <ShiftModal
        isOpen={isShiftModalOpen}
        onClose={() => setIsShiftModalOpen(false)}
        shiftData={shiftData}
        currentUser={currentUser}
        onAcknowledgeShift={handleAcknowledgeShift}
      />

      <AuditModal
        isOpen={isAuditModalOpen}
        onClose={() => setIsAuditModalOpen(false)}
        auditLogs={auditLogs}
      />
    </div>
  );
}
