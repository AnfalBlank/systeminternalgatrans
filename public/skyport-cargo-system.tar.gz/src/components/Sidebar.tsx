import React from 'react';
import {
  LayoutDashboard,
  Boxes,
  ScanLine,
  Columns3,
  ShieldAlert,
  ShieldCheck,
  FileText,
  Clock,
  History,
  Settings,
  Plane,
  ChevronRight,
} from 'lucide-react';
import { Language, translations } from '../i18n/translations';

export type NavTab =
  | 'dashboard'
  | 'consignments'
  | 'xray'
  | 'kanban'
  | 'avsec'
  | 'exceptions'
  | 'handover'
  | 'shift'
  | 'audit'
  | 'settings';

interface SidebarProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  openExceptionsCount: number;
  pendingXrayCount: number;
  pendingAvsecCount: number;
  onOpenShiftModal: () => void;
  currentLang: Language;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  openExceptionsCount,
  pendingXrayCount,
  pendingAvsecCount,
  onOpenShiftModal,
  currentLang,
}) => {
  const t = translations[currentLang];

  const menuItems: { id: NavTab; label: string; icon: React.ReactNode; badge?: number; badgeColor?: string }[] = [
    { id: 'dashboard', label: t.navDashboard, icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'consignments', label: t.navConsignments, icon: <Boxes className="w-5 h-5" /> },
    {
      id: 'xray',
      label: t.navXray,
      icon: <ScanLine className="w-5 h-5" />,
      badge: pendingXrayCount > 0 ? pendingXrayCount : undefined,
      badgeColor: 'bg-blue-100 text-blue-700',
    },
    { id: 'kanban', label: t.navKanban, icon: <Columns3 className="w-5 h-5" /> },
    {
      id: 'avsec',
      label: t.navAvsec,
      icon: <ShieldCheck className="w-5 h-5" />,
      badge: pendingAvsecCount > 0 ? pendingAvsecCount : undefined,
      badgeColor: 'bg-emerald-100 text-emerald-700',
    },
    {
      id: 'exceptions',
      label: t.navExceptions,
      icon: <ShieldAlert className="w-5 h-5" />,
      badge: openExceptionsCount > 0 ? openExceptionsCount : undefined,
      badgeColor: 'bg-rose-100 text-rose-700',
    },
    { id: 'handover', label: t.navHandover, icon: <FileText className="w-5 h-5" /> },
    { id: 'shift', label: t.navShift, icon: <Clock className="w-5 h-5" /> },
    { id: 'audit', label: t.navAudit, icon: <History className="w-5 h-5" /> },
    { id: 'settings', label: t.navSettings, icon: <Settings className="w-5 h-5" /> },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200/80 flex flex-col shrink-0 min-h-screen select-none">
      {/* Brand Logo Zone */}
      <div className="h-18 px-6 flex items-center gap-3 border-b border-slate-100">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white shadow-sm shadow-blue-500/20">
          <Plane className="w-5 h-5 transform -rotate-45" />
        </div>
        <div>
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-slate-900 tracking-tight text-lg">{t.appName}</span>
            <span className="text-[10px] uppercase tracking-wider font-semibold px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200/60 font-mono">
              Ops
            </span>
          </div>
          <p className="text-[11px] text-slate-400 font-medium">{t.appSub}</p>
        </div>
      </div>

      {/* Nav List */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
          {t.operationalCore}
        </div>
        {menuItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 cursor-pointer ${
                isActive
                  ? 'bg-blue-50/90 text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className={isActive ? 'text-blue-600' : 'text-slate-400 group-hover:text-slate-600'}>
                  {item.icon}
                </span>
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span
                  className={`text-[11px] font-semibold px-2 py-0.5 rounded-full font-mono tabular-nums ${
                    item.badgeColor || 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Shift Live Card at Bottom */}
      <div className="p-3 m-3 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white shadow-md relative overflow-hidden">
        <div className="absolute -right-4 -bottom-4 w-20 h-20 bg-blue-500/10 rounded-full blur-xl pointer-events-none" />
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[11px] font-medium text-emerald-300">{t.shiftActive}</span>
          </div>
          <span className="text-[10px] text-slate-300 font-mono">{t.shiftHours}</span>
        </div>
        <p className="text-xs font-semibold text-slate-100 leading-snug">{t.terminalCargo}</p>
        <p className="text-[11px] text-slate-300 mt-1">{t.slaComplianceRate}</p>
        <button
          onClick={onOpenShiftModal}
          className="mt-3 w-full py-1.5 px-3 bg-white/10 hover:bg-white/20 active:scale-[0.98] transition-all text-xs font-medium rounded-lg flex items-center justify-center gap-1.5 text-white cursor-pointer border border-white/15"
        >
          <Clock className="w-3.5 h-3.5 text-blue-300" />
          <span>{t.shiftLogbookBtn}</span>
          <ChevronRight className="w-3.5 h-3.5 ml-auto text-slate-400" />
        </button>
      </div>
    </aside>
  );
};
