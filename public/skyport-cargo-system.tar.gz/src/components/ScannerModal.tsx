import React, { useState } from 'react';
import {
  Scan,
  X,
  Search,
  CheckCircle2,
  AlertTriangle,
  Barcode,
  Package,
  Layers,
  Sparkles,
} from 'lucide-react';
import { Consignment } from '../types/cargo';

interface ScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  consignments: Consignment[];
  onAddNewConsignment: (newConsignment: Consignment) => void;
  onLogScanEvent: (barcode: string, result: string) => void;
}

export const ScannerModal: React.FC<ScannerModalProps> = ({
  isOpen,
  onClose,
  consignments,
  onAddNewConsignment,
  onLogScanEvent,
}) => {
  const [barcodeInput, setBarcodeInput] = useState('');
  const [scanResult, setScanResult] = useState<{
    status: 'success' | 'warning' | 'error' | null;
    message: string;
    consignment?: Consignment;
  }>({ status: null, message: '' });

  if (!isOpen) return null;

  // Preset quick scans for demonstration
  const presets = [
    { label: 'AWB 126-89412045 (Valid Garmin ICs)', code: '126-89412045' },
    { label: 'AWB 157-77291044 (Sumatra Coffee - Threat Hold)', code: '157-77291044' },
    { label: 'AWB 999-12048591 (Orchids - Missing Piece)', code: '999-12048591' },
    { label: 'Unregistered AWB 888-71049281 (Auto CSD Lookup)', code: '888-71049281' },
    { label: 'Damaged Barcode Syntax (Trigger Exception)', code: 'ERR#BAD_BARCODE' },
  ];

  const handleScan = (codeToScan?: string) => {
    const code = (codeToScan || barcodeInput).trim();
    if (!code) return;

    onLogScanEvent(code, 'KEYBOARD_WEDGE_SCAN');

    // Rule CR-02: Format validation
    if (code.includes('ERR#') || code.length < 8) {
      setScanResult({
        status: 'error',
        message: `CR-02 Rule Triggered: Unreadable/Damaged Barcode syntax [${code}]. Automatic Exception Case created per SOP §4.1.`,
      });
      return;
    }

    // Check existing
    const existing = consignments.find((c) => c.awbNumber === code);
    if (existing) {
      setScanResult({
        status: 'success',
        message: `AWB [${code}] found in local registry. Flight: ${existing.flightNo} (${existing.airline}). Pieces: ${existing.totalDeclaredPieces}. Status: ${existing.status}.`,
        consignment: existing,
      });
    } else {
      // Simulate CSD API Lookup
      const newConsignment: Consignment = {
        id: `CNS-${Date.now().toString().slice(-4)}`,
        awbNumber: code,
        sourceReference: `CSD-INTL-${Date.now().toString().slice(-5)}`,
        dataVersion: 1,
        shipper: 'PT Global Maritime Logistics',
        consignee: 'EuroCargo Logistics BV',
        origin: 'CGK',
        destination: 'AMS',
        airline: 'Garuda Indonesia Cargo',
        flightNo: 'GA-088',
        departureTime: '20:15',
        cutoffTime: '17:30',
        natureOfGoods: 'Perishable Herbal & Organic Extracts',
        specialHandling: 'GENERAL · PERISHABLE',
        totalDeclaredPieces: 10,
        totalReceivedPieces: 10,
        totalWeightKg: 180.0,
        status: 'AWAITING_XRAY',
        slaStatus: 'NOMINAL',
        slaMinutesRemaining: 180,
        priority: 'NORMAL',
        pieces: Array.from({ length: 10 }, (_, i) => ({
          id: `PCS-NEW-${i + 1}`,
          pieceNo: i + 1,
          barcode: `${code}-P${String(i + 1).padStart(2, '0')}`,
          weightKg: 18.0,
          dimensionsCm: '40x35x25',
          status: 'AWAITING_XRAY',
        })),
        xrayInspections: [],
        exceptionIds: [],
        createdAt: new Date().toLocaleTimeString(),
        lastUpdatedAt: new Date().toLocaleTimeString(),
      };

      onAddNewConsignment(newConsignment);
      setScanResult({
        status: 'success',
        message: `CSD Lookup Successful: AWB [${code}] verified from verified CSD snapshot. 10 Pieces registered into X-Ray queue.`,
        consignment: newConsignment,
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <Scan className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Handheld Barcode / QR Scanner Simulator</h3>
              <p className="text-xs text-slate-500">USB / Bluetooth Wedge Mode · FR-03 & CR-02 Compliance</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-200/60 flex items-center justify-center text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Scan input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Scan Barcode / Enter AWB Number
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Barcode className="w-5 h-5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={barcodeInput}
                  onChange={(e) => setBarcodeInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleScan()}
                  placeholder="e.g. 126-89412045 or scan with physical scanner..."
                  className="w-full pl-10 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  autoFocus
                />
              </div>
              <button
                onClick={() => handleScan()}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-[0.98] text-white text-xs font-semibold rounded-xl transition-all cursor-pointer shadow-xs"
              >
                Scan / Lookup
              </button>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Supports continuous scanner keystrokes. Idempotent deduplication enabled (CR-10).
            </p>
          </div>

          {/* Preset Buttons */}
          <div>
            <p className="text-xs font-semibold text-slate-600 mb-2">Simulate Test Scenarios:</p>
            <div className="space-y-1.5">
              {presets.map((preset) => (
                <button
                  key={preset.code}
                  onClick={() => {
                    setBarcodeInput(preset.code);
                    handleScan(preset.code);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl border border-slate-200 hover:border-blue-300 hover:bg-blue-50/50 text-xs font-medium text-slate-700 transition-all flex items-center justify-between cursor-pointer"
                >
                  <span className="truncate">{preset.label}</span>
                  <span className="font-mono text-[10px] text-slate-400 shrink-0 ml-2">{preset.code}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Scan Result Feedback */}
          {scanResult.status && (
            <div
              className={`p-4 rounded-2xl border text-xs leading-relaxed ${
                scanResult.status === 'success'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : scanResult.status === 'warning'
                  ? 'bg-amber-50 border-amber-200 text-amber-900'
                  : 'bg-rose-50 border-rose-200 text-rose-900'
              }`}
            >
              <div className="flex items-center gap-2 font-semibold mb-1">
                {scanResult.status === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                {scanResult.status === 'error' && <AlertTriangle className="w-4 h-4 text-rose-600" />}
                <span>
                  {scanResult.status === 'success' ? 'Verification Passed' : 'Security / Data Flag'}
                </span>
              </div>
              <p>{scanResult.message}</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>Scanner Wedge: Ready</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Close Scanner
          </button>
        </div>
      </div>
    </div>
  );
};
