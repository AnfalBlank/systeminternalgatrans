import React, { useState } from 'react';
import {
  Layers,
  X,
  CheckCircle2,
  AlertTriangle,
  Barcode,
  Scale,
  ShieldCheck,
  Check,
  Scan,
} from 'lucide-react';
import { Consignment, Piece } from '../types/cargo';

interface PieceModalProps {
  isOpen: boolean;
  onClose: () => void;
  consignment: Consignment | null;
  onUpdatePieceHandover: (consignmentId: string, pieceId: string, verified: boolean) => void;
}

export const PieceModal: React.FC<PieceModalProps> = ({
  isOpen,
  onClose,
  consignment,
  onUpdatePieceHandover,
}) => {
  const [pieceScanInput, setPieceScanInput] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);

  if (!isOpen || !consignment) return null;

  const handleSimulatePieceScan = (e: React.FormEvent) => {
    e.preventDefault();
    const barcode = pieceScanInput.trim();
    if (!barcode) return;

    const matchedPiece = consignment.pieces.find((p) => p.barcode.toLowerCase() === barcode.toLowerCase());
    if (matchedPiece) {
      onUpdatePieceHandover(consignment.id, matchedPiece.id, true);
      setFeedback(`Verified Piece #${matchedPiece.pieceNo} [${matchedPiece.barcode}]. Identity reconciled.`);
      setPieceScanInput('');
    } else {
      setFeedback(`CR-04 Error: Barcode [${barcode}] does not match any piece registered to AWB ${consignment.awbNumber}!`);
    }
  };

  const verifiedCount = consignment.pieces.filter((p) => p.scannedAtHandover).length;
  const allVerified = verifiedCount === consignment.pieces.length && consignment.pieces.length > 0;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-900 text-base">Piece-Level Tracking & Reconciliation</h3>
                <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-semibold">
                  AWB {consignment.awbNumber}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                FR-05 & CR-04 Compliance · Individual Piece Identification & Handover Verification
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-200/60 flex items-center justify-center text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Consignment Snapshot */}
        <div className="px-6 py-3 bg-blue-50/60 border-b border-blue-100 text-xs flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-4">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Flight & Carrier</span>
              <span className="font-bold text-slate-900 font-mono">{consignment.flightNo} · {consignment.destination}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Declared vs Received</span>
              <span className="font-bold text-slate-900 font-mono">
                {consignment.totalReceivedPieces} / {consignment.totalDeclaredPieces} Units ({consignment.totalWeightKg} kg)
              </span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Handover Verified</span>
              <span className={`font-bold font-mono ${allVerified ? 'text-emerald-700' : 'text-blue-700'}`}>
                {verifiedCount} / {consignment.pieces.length} Units
              </span>
            </div>
          </div>

          {/* Piece Barcode Wedge Simulator input */}
          <form onSubmit={handleSimulatePieceScan} className="flex items-center gap-1.5">
            <input
              type="text"
              value={pieceScanInput}
              onChange={(e) => setPieceScanInput(e.target.value)}
              placeholder="Scan individual piece label..."
              className="px-2.5 py-1 text-xs bg-white border border-slate-300 rounded-lg font-mono focus:outline-none focus:ring-1 focus:ring-blue-500 w-52"
            />
            <button
              type="submit"
              className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer"
            >
              <Scan className="w-3.5 h-3.5" />
              <span>Verify</span>
            </button>
          </form>
        </div>

        {/* Feedback Alert if scan occurred */}
        {feedback && (
          <div
            className={`px-6 py-2 text-xs border-b ${
              feedback.includes('Error')
                ? 'bg-rose-50 text-rose-800 border-rose-200'
                : 'bg-emerald-50 text-emerald-800 border-emerald-200'
            }`}
          >
            {feedback}
          </div>
        )}

        {/* Piece Table */}
        <div className="flex-1 overflow-y-auto p-6">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 uppercase text-[10px] tracking-wider font-semibold">
                <th className="pb-2.5">Piece #</th>
                <th className="pb-2.5">Individual Barcode</th>
                <th className="pb-2.5">Weight / Dimensions</th>
                <th className="pb-2.5">X-Ray Status</th>
                <th className="pb-2.5">Current Status</th>
                <th className="pb-2.5 text-right">Handover Verified</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {consignment.pieces.map((piece) => {
                const isHold = piece.xrayResult === 'HOLD';
                return (
                  <tr key={piece.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2.5 font-mono font-semibold text-slate-900">
                      #{String(piece.pieceNo).padStart(2, '0')}
                    </td>
                    <td className="py-2.5 font-mono text-slate-800 flex items-center gap-1.5">
                      <Barcode className="w-3.5 h-3.5 text-slate-400" />
                      <span>{piece.barcode}</span>
                    </td>
                    <td className="py-2.5 font-mono text-slate-600">
                      {piece.weightKg} kg · {piece.dimensionsCm} cm
                    </td>
                    <td className="py-2.5">
                      {piece.xrayResult ? (
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-semibold font-mono ${
                            piece.xrayResult === 'PASS'
                              ? 'bg-emerald-100 text-emerald-800'
                              : piece.xrayResult === 'HOLD'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {piece.xrayResult}
                        </span>
                      ) : (
                        <span className="text-slate-400 italic text-[11px]">Pending Scan</span>
                      )}
                    </td>
                    <td className="py-2.5 font-mono text-slate-600 text-[11px]">
                      {piece.status.replace(/_/g, ' ')}
                    </td>
                    <td className="py-2.5 text-right">
                      <button
                        onClick={() => onUpdatePieceHandover(consignment.id, piece.id, !piece.scannedAtHandover)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                          piece.scannedAtHandover
                            ? 'bg-emerald-600 text-white shadow-2xs'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                        }`}
                      >
                        <Check className="w-3 h-3 stroke-[3]" />
                        <span>{piece.scannedAtHandover ? 'Reconciled' : 'Check In'}</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>CR-04 Rule: Total count matches and piece IDs uniquely reconciled.</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};
