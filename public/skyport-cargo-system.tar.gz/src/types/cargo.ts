export type UserRole =
  | 'RECEIVING_ADMIN'
  | 'XRAY_OPERATOR'
  | 'AVSEC_OFFICER'
  | 'DISPATCH_OFFICER'
  | 'WAREHOUSE_RECEIVER'
  | 'SHIFT_SUPERVISOR'
  | 'OPERATIONS_MANAGER'
  | 'AUDITOR';

export interface UserProfile {
  id: string;
  name: string;
  role: UserRole;
  roleLabel: string;
  badgeId: string;
  avatarColor: string;
  initials: string;
  station: string;
  dutyStatus: 'Online' | 'In Screening' | 'Reviewing' | 'On Break' | 'Active';
}

export type ConsignmentStatus =
  | 'RECEIVED'
  | 'DATA_EXCEPTION'
  | 'PIECE_RECONCILIATION'
  | 'AWAITING_XRAY'
  | 'XRAY_HOLD'
  | 'XRAY_REVIEW_REQUIRED'
  | 'XRAY_REJECTED'
  | 'AWAITING_AVSEC'
  | 'AVSEC_REJECTED_OR_HELD'
  | 'AVSEC_APPROVED'
  | 'DO_DRAFT'
  | 'DO_ISSUED'
  | 'AWAITING_WAREHOUSE_HANDOVER'
  | 'HANDOVER_DISCREPANCY'
  | 'DELIVERED'
  | 'CANCELLED';

export type PieceStatus =
  | 'REGISTERED'
  | 'RECEIVED'
  | 'AWAITING_XRAY'
  | 'XRAY_PASS'
  | 'XRAY_HOLD'
  | 'XRAY_REVIEW_REQUIRED'
  | 'XRAY_REJECTED'
  | 'AVSEC_PENDING'
  | 'AVSEC_APPROVED'
  | 'DO_ASSIGNED'
  | 'HANDED_OVER'
  | 'DISCREPANCY'
  | 'CANCELLED';

export type XRayResult = 'PASS' | 'HOLD' | 'REVIEW_REQUIRED' | 'REJECT';

export interface Piece {
  id: string;
  pieceNo: number;
  barcode: string;
  weightKg: number;
  dimensionsCm: string; // e.g. "40x30x25"
  status: PieceStatus;
  xrayResult?: XRayResult;
  xrayTimestamp?: string;
  xrayOperator?: string;
  scannedAtHandover?: boolean;
  notes?: string;
}

export interface XRayInspection {
  id: string;
  inspectedAt: string;
  operatorId: string;
  operatorName: string;
  stationId: string;
  scannerModel: string;
  result: XRayResult;
  notes: string;
  dataVersion: number;
  densityLevel: 'Low' | 'Medium' | 'High' | 'Suspicious';
  threatClass?: 'None' | 'Organic Mass' | 'Shielded Object' | 'Battery/Hazmat' | 'Unidentified';
  imageSimUrl?: string;
}

export interface AVSECReview {
  id: string;
  decidedAt: string;
  officerId: string;
  officerName: string;
  decision: 'APPROVED' | 'REJECTED' | 'HELD_FOR_SECONDARY';
  reason: string;
  reviewedDataVersion: number;
  securityStampNo: string;
}

export interface DeliveryOrder {
  id: string;
  doNumber: string;
  version: number;
  status: 'DRAFT' | 'PENDING_VERIFICATION' | 'ISSUED' | 'AMENDED' | 'CANCELLED';
  issuedAt?: string;
  issuedBy?: string;
  dispatcherName?: string;
  carrier: string;
  flightNo: string;
  destination: string;
  customsSealNo: string;
  totalPieces: number;
  totalGrossWeightKg: number;
}

export interface ProofOfHandover {
  id: string;
  proofNo: string;
  handoverTime: string;
  doNumber: string;
  handedOverBy: string; // Dispatch officer
  receivedBy: string; // Warehouse receiver
  airlineWarehouse: string;
  plannedPieces: number;
  actualPieces: number;
  conditionStatus: 'INTACT_SEAL' | 'MINOR_TEAR' | 'DAMAGED_CRUSHED' | 'SEAL_BROKEN';
  digitalSignature: string;
  notes: string;
  verifiedPieceIds: string[];
}

export interface ExceptionCase {
  id: string;
  caseNo: string;
  category:
    | 'BARCODE_UNREADABLE'
    | 'CSD_MISMATCH'
    | 'XRAY_THREAT_HOLD'
    | 'PIECE_COUNT_MISMATCH'
    | 'PIECE_IDENTITY_CONFLICT'
    | 'AVSEC_REJECTED'
    | 'DO_VERIFICATION_FAILED'
    | 'HANDOVER_DISCREPANCY'
    | 'SYSTEM_OFFLINE_RECON';
  title: string;
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  status: 'OPEN' | 'ASSIGNED' | 'IN_PROGRESS' | 'PENDING_REVIEW' | 'RESOLVED' | 'CLOSED';
  consignmentId: string;
  awbNumber: string;
  pieceId?: string;
  assignedTo: string;
  createdAt: string;
  dueAt: string;
  resolvedAt?: string;
  resolutionNotes?: string;
  chronology: {
    timestamp: string;
    actor: string;
    action: string;
    note: string;
  }[];
}

export interface Consignment {
  id: string;
  awbNumber: string;
  sourceReference: string; // e.g. "CSD-2026-ID-8831"
  dataVersion: number;
  shipper: string;
  consignee: string;
  origin: string; // e.g. "CGK"
  destination: string; // e.g. "NRT", "SIN", "DOH", "DXB"
  airline: string; // e.g. "Garuda Indonesia", "Singapore Airlines", "Qatar Cargo"
  flightNo: string;
  departureTime: string;
  cutoffTime: string;
  natureOfGoods: string;
  specialHandling?: string; // "PERISHABLE", "DGR-CLASS 9", "VALUABLE", "GENERAL"
  totalDeclaredPieces: number;
  totalReceivedPieces: number;
  totalWeightKg: number;
  status: ConsignmentStatus;
  slaStatus: 'NOMINAL' | 'WARNING' | 'OVERDUE';
  slaMinutesRemaining: number;
  priority: 'HIGH' | 'MEDIUM' | 'NORMAL';
  pieces: Piece[];
  xrayInspections: XRayInspection[];
  avsecReview?: AVSECReview;
  deliveryOrder?: DeliveryOrder;
  proofOfHandover?: ProofOfHandover;
  exceptionIds: string[];
  createdAt: string;
  lastUpdatedAt: string;
}

export interface ShiftHandover {
  id: string;
  shiftCode: string; // e.g. "SHIFT-1 (06:00 - 14:00)"
  date: string;
  station: string;
  outgoingSupervisor: string;
  incomingSupervisor: string;
  status: 'PENDING_ACKNOWLEDGMENT' | 'ACKNOWLEDGED';
  acknowledgedAt?: string;
  summary: {
    totalAccepted: number;
    totalXrayed: number;
    totalAvsecCleared: number;
    totalDoIssued: number;
    totalDelivered: number;
    openExceptionsCount: number;
    pendingXrayCount: number;
    pendingAvsecCount: number;
    undeliveredDoCount: number;
  };
  handoverNotes: string;
  openItems: {
    refType: 'AWB' | 'EXCEPTION' | 'DO';
    refId: string;
    detail: string;
    actionRequired: string;
  }[];
}

export interface AuditEvent {
  id: string;
  occurredAt: string;
  actor: string;
  role: UserRole;
  action: string;
  entityType: 'CONSIGNMENT' | 'PIECE' | 'XRAY' | 'AVSEC' | 'DO' | 'HANDOVER' | 'EXCEPTION';
  entityId: string;
  description: string;
  changes?: {
    field: string;
    before: string;
    after: string;
  }[];
  criticalControlMet: boolean;
  correlationId: string;
}
